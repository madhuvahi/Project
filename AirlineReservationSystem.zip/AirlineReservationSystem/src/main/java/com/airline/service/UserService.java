package com.airline.service;

import java.util.List;

import com.airline.model.Flight;
import com.airline.model.Login;
import com.airline.model.User;

public interface UserService {
	void register(User user);
	User validateUser(Login login);
	public List<Flight> findFlight(Flight flight);
	public Flight getDetails(int flightid);
}
